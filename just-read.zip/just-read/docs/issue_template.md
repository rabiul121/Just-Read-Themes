> Thanks for wanting to help improve Just Read! 
> 
> Please look through [the frequently asked questions](https://github.com/ZachSaucier/Just-Read#faq) and [the existing issues](https://github.com/ZachSaucier/Just-Read/issues?utf8=%E2%9C%93&q=is%3Aissue+) to make sure you're not asking what has already been discussed elsewhere.
> 
> Please delete this text from your post before posting.
